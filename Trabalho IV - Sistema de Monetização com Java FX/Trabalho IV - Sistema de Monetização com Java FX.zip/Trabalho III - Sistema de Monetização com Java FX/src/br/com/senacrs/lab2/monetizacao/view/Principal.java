
package br.com.senacrs.lab2.monetizacao.view;

import br.com.senacrs.lab2.monetizacao.model.jdbc.Conexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Lucas Fraga
 * 
 * Referencias usadas para a implementação do Java FX
 * https://www.youtube.com/watch?v=_Ke7CiTdmiI&list=PL-mvLy2ws8ILNrs8jtEAwaZMxDZvlMj48&index=1
 * https://www.youtube.com/watch?v=Cx7w8FmGuJY&list=PL-mvLy2ws8ILNrs8jtEAwaZMxDZvlMj48&index=2
 * https://www.youtube.com/watch?v=YoOpUbF6Hh4&list=PL-mvLy2ws8ILNrs8jtEAwaZMxDZvlMj48&index=3
 */
public class Principal extends Application {
    
    // Iniciar conexão com banco de dados
    private Connection con = Conexao.getConnection();
    
    @Override
    public void start(Stage stage) throws IOException, SQLException {
        if (con.isClosed()) {
            System.out.println("Não foi possível estabelecer conexão com o banco de dados.");
            System.out.println("Verifique se: ");
            System.out.println("1 - Banco de dados está em execução; ");
            System.out.println("2 - Driver do JDBC foi adicionado ao projeto.");

        } else {
            Parent root = FXMLLoader.load(getClass().getResource("../view/MenuFuncionario.fxml"));

            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setResizable(false);
            stage.setTitle("Sistema de Monetização");
            stage.show();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    public void closeConnection() throws SQLException {
        con.close();
    }
}
