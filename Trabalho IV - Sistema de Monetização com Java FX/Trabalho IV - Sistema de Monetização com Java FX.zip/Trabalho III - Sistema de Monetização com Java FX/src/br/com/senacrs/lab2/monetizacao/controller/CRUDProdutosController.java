
package br.com.senacrs.lab2.monetizacao.controller;

import br.com.senacrs.lab2.monetizacao.model.entidades.Produto;
import br.com.senacrs.lab2.monetizacao.model.jdbc.ProdutoDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CRUDProdutosController implements Initializable { 
    
    @FXML
    private AnchorPane painelCRUDProdutos;

    @FXML
    private TableView<Produto> tableViewProdutos;
    
    @FXML
    private TableColumn<Produto, String> id;

    @FXML
    private TableColumn<Produto, String> nome;

    @FXML
    private TableColumn<Produto, String> preco;

    @FXML
    private Label labelID;

    @FXML
    private Label labelNome;

    @FXML
    private Label labelPreco;

    @FXML
    private Button inserir;

    @FXML
    private Button alterar;

    @FXML
    private Button remover;
    
    @FXML
    private Button voltar;
    
    private List<Produto> listaProdutos;
    private ObservableList<Produto> observableListProdutos;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            carregarTableViewProduto();
           
            tableViewProdutos.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> selecionarItemTableViewProdutos(newValue));

    }    
    
    public void carregarTableViewProduto() {
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        
        listaProdutos = ProdutoDAO.listaDeProdutos();
        
        observableListProdutos = FXCollections.observableArrayList(listaProdutos);
        tableViewProdutos.setItems(observableListProdutos);
    }
    
    @FXML
    private void selecionarItemTableViewProdutos(Produto produto) {
        labelID.setText(String.valueOf(produto.getId()));
        labelNome.setText(produto.getNome());
        labelPreco.setText(String.valueOf(produto.getPreco()));
    }
    
    @FXML
    private void voltar(ActionEvent event) throws IOException {
        Stage stage = (Stage) painelCRUDProdutos.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleButtonInserir() throws IOException {
        Produto produto = new Produto(0, null, 0.0);
        boolean buttonConfirmarClicked = showCRUDProdutosDialogController(produto);
        if (buttonConfirmarClicked) {
            ProdutoDAO.salvar(produto);
            carregarTableViewProduto();
        }
    }
    
    @FXML
    private void handleButtonAlterar() throws IOException {
        Produto produto = tableViewProdutos.getSelectionModel().getSelectedItem();
        if (produto != null) {
            boolean buttonConfirmarClicked = showCRUDProdutosDialogController(produto);
            
            if (buttonConfirmarClicked) {
             ProdutoDAO.atualizar(produto);
             carregarTableViewProduto();   
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, selecione um produto na tabela!");
            alert.show();
        }
    }
    
    @FXML
    private void handleButtonRemover() throws IOException {
        Produto produto = tableViewProdutos.getSelectionModel().getSelectedItem();
        if (produto != null) {
            ProdutoDAO.deletar(produto);
            carregarTableViewProduto();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, selecione um produto na tabela!");
            alert.show();
        }
    }
    
    public boolean showCRUDProdutosDialogController(Produto produto) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(CRUDProdutosDialogController.class.getResource("/br/com/senacrs/lab2/monetizacao/view/CRUDProdutosDialog.fxml"));
        AnchorPane page = (AnchorPane) loader.load();
        
        Stage dialogStage = new Stage();
        dialogStage.setTitle("CRUD de produtos");
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);
        
        CRUDProdutosDialogController controller = loader.getController();
        controller.setDialogStage(dialogStage);
        controller.setProduto(produto);
        
        dialogStage.showAndWait();
        
        return controller.isButtonConfirmarClicked();
    }
}
