
package br.com.senacrs.lab2.monetizacao.controller;

import br.com.senacrs.lab2.monetizacao.model.entidades.Produto;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class CRUDProdutosDialogController implements Initializable {

    @FXML
    private Label labelProdutoCodigo;

    @FXML
    private Label labelProdutoNome;

    @FXML
    private Label labelProdutoPreco;

    @FXML
    private TextField textFieldProdutoCodigo;

    @FXML
    private TextField textFieldProdutoNome;

    @FXML
    private TextField textFieldProdutoPreco;

    @FXML
    private Button buttonConfirmar;

    @FXML
    private Button buttonCancelar;
    
    private Stage dialogStage;
    private boolean buttonConfirmarClicked = false;
    private Produto produto;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    public Stage getDialogStage() {
        return dialogStage;
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public boolean isButtonConfirmarClicked() {
        return buttonConfirmarClicked;
    }

    public void setButtonConfirmarClicked(boolean buttonConfirmarClicked) {
        this.buttonConfirmarClicked = buttonConfirmarClicked;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
        
        this.textFieldProdutoCodigo.setText(String.valueOf(produto.getId()));
        this.textFieldProdutoNome.setText(produto.getNome());
        this.textFieldProdutoPreco.setText(String.valueOf(produto.getPreco()));
    }
    
    @FXML
    public void handleButtonConfirmar() {
        
        if(validarEntradaDeDados()) {
            produto.setId(Integer.parseInt(textFieldProdutoCodigo.getText()));
            produto.setNome(textFieldProdutoNome.getText());
            produto.setPreco(Double.parseDouble(textFieldProdutoPreco.getText()));

            buttonConfirmarClicked = true;
            dialogStage.close();
        }
    }
    
    @FXML
    public void handleButtonCancelar() {
        dialogStage.close();
    }
    
    /* Validações */
    public static boolean isInteger(Object object) {
            if (object instanceof Integer) {
                    return true;
            } else {
                    String string = object.toString();

                    try {
                            Integer.parseInt(string);
                    } catch(Exception e) {
                            return false;
                    }	
            }

        return true;
    }

    public static boolean isDouble(Object object) {
            if (object instanceof Double) {
                    return true;
            } else {
                    String string = object.toString();

                    try {
                            Double.parseDouble(string);
                    } catch(Exception e) {
                            return false;
                    }	
            }

        return true;
    }
    
    public static boolean isString(String string) {
        char[] c = string.toCharArray();
        boolean d = true;
        for ( int i = 0; i < c.length; i++ ) {
            if ( !Character.isDigit( c[ i ] ) ) {
                d = false;
                break;
            }
        }
        return d;
    }
    
    private boolean validarEntradaDeDados() {
        String errorMessage = "";

        if (textFieldProdutoNome.getText() == null || textFieldProdutoNome.getText().length() == 0 || isString(textFieldProdutoNome.getText()) != true) {
            errorMessage += "Nome inválido!\n";
        }
        if (textFieldProdutoCodigo.getText() == null || textFieldProdutoCodigo.getText().length() == 0 || isInteger(textFieldProdutoCodigo.getText()) != true || Integer.parseInt(textFieldProdutoCodigo.getText()) <= 0) {
            errorMessage += "Código inválido!\n";
        }
        if (textFieldProdutoPreco.getText() == null || textFieldProdutoPreco.getText().length() == 0 || Double.parseDouble(textFieldProdutoPreco.getText()) <= 0) {
            errorMessage += "Preço inválido!\n";
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Mostrando a mensagem de erro
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro no cadastro");
            alert.setHeaderText("Campos inválidos, por favor, corrija...");
            alert.setContentText(errorMessage);
            alert.show();
            return false;
        }
    }
}
